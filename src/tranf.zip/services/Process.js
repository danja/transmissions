import { ServiceBase } from './ServiceBase.js'

export class Process extends ServiceBase {

    process(input) {
        return input
    }
}