import { Injectable } from '../di/Injectable.js';

export class Process extends Injectable {

    process(input) {
        return input
    }
}