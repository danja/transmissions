
import SimplePipe from '../SimplePipe.js';
console.log('Testing SimplePipe...');

// Example test (to be replaced with actual tests)
const instance = new SimplePipe();
console.log(instance ? 'Test passed' : 'Test failed');
