
import Process from '../Process.js';
console.log('Testing Process...');

// Example test (to be replaced with actual tests)
const instance = new Process();
console.log(instance ? 'Test passed' : 'Test failed');
