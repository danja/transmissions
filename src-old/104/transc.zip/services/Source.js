import { ServiceBase } from './ServiceBase.js'

export class Source extends ServiceBase {

    read(sourceID) {
        return "Source interface called, oops."
    }
}




