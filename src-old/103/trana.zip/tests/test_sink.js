
import { Sink } from '../'../services/Sink';

// Test for Sink
console.log('Testing Sink...';

try {
    const instance = new Sink();
    console.log('Sink Test Passed';
} catch (error) {
    console.error('Sink Test Failed:', error.message);
}
