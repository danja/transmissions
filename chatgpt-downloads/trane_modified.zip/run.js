import logger from './utils/Logger.js'
logger.log("Logger module loaded successfully.")

logger.setLogLevel("debug")
logger.log("Hello, logger!")

import { NodeInjector } from './di/NodeInjector.js'
import simplepipe from './simplepipe.json' assert { type: 'json' };

const di = new NodeInjector(simplepipe.pipe)
logger.log("NodeInjector instance created successfully.")

import { SimplePipe } from './transmissions/SimplePipe.js'
const app = di.make(SimplePipe)
logger.log("SimplePipe instance created successfully.")

const inputFilePath = './input.txt';
const outputFilePath = './output.txt';

logger.log("Starting the application run.")
app.run(inputFilePath, outputFilePath);
logger.log("Application run completed.")
/*
(async () => {
    const result = await app.runTransmission();
    console.log('Transmission result:', result);
})();
*/