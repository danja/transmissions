
import ServiceContainer from "./ServiceContainer.js";

export default class Pipeline {
    constructor(config) {
        this.config = config;
        this.container = new ServiceContainer();
    }

    async constructPipeline() {
        
// Updated pipeline construction logic using ServiceFactory
import ServiceFactory from "./ServiceFactory.js";

// Example pipeline construction logic using the factory
this.services = this.config.map(serviceConfig => ServiceFactory.createService(serviceConfig.type, serviceConfig));

    }
}
