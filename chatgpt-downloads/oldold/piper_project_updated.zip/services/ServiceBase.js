import { Injectable } from '../di/Injectable.js';

export class ServiceBase extends Injectable {

}




