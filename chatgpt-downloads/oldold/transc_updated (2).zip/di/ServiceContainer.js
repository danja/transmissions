
import { Transmission } from './Transmission.js'
import { ServiceFactory } from './ServiceFactory.js'
import { Connector } from '../services/Connector.js'
import { StringSource } from '../services/StringSource.js'
import { StringSink } from '../services/StringSink.js'
import { AppendProcess } from '../services/AppendProcess.js'

export class ServiceContainer {
  constructor(transmission) {
    // Dynamically create definitions based on the transmission configuration
    this.definitions = {};
    this.transmission = transmission;
    transmission.forEach(item => {
      this.definitions[item.node.toLowerCase()] = item.node; // Ensuring correct key usage
    })

    // Store for service instances for reuse
    this.instances = {};

    // Store the entire transmission configuration for each service
    this.transmissionConfig = transmission;
  }

  getService(serviceName) {
    // Create a service instance if one doesn't already exist
    if (!this.instances[serviceName]) {
      const ServiceClass = this.definitions[serviceName];
      if (ServiceClass) {
        // Find the specific configuration for this service
        const serviceConfig = this.transmissionConfig.find(item => item.node.toLowerCase() === serviceName);
        // Pass the configuration to the ServiceFactory
        this.instances[serviceName] = ServiceFactory.createService(ServiceClass, serviceConfig.config);
      } else {
        throw new Error('Service "' + serviceName + '" is not defined.');
      }
    }
    return this.instances[serviceName];
  }
}
