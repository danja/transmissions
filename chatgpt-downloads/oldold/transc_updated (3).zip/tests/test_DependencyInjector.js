
import NodeInjector from '../NodeInjector.js';
console.log('Testing NodeInjector...');

// Example test (to be replaced with actual tests)
const instance = new NodeInjector();
console.log(instance ? 'Test passed' : 'Test failed');
