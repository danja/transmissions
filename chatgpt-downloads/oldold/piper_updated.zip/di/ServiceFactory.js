
export class ServiceFactory {
    static createService(type, config) {

        if (type === 'SomeService') {
            return new SomeService(config);
        }

        // Adding support for Connector class
        if (type === 'Connector') {
            return new Connector(config);
        }

        return null;

    }
}
