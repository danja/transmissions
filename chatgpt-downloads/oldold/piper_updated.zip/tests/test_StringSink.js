
import StringSink from '../StringSink.js';
console.log('Testing StringSink...');

// Example test (to be replaced with actual tests)
const instance = new StringSink();
console.log(instance ? 'Test passed' : 'Test failed');
