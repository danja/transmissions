
import StringSource from '../StringSource.js';
console.log('Testing StringSource...');

// Example test (to be replaced with actual tests)
const instance = new StringSource();
console.log(instance ? 'Test passed' : 'Test failed');
