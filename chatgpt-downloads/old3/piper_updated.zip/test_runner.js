
const fs = require('fs');
const path = require('path');

const testFiles = fs.readdirSync(__dirname).filter(file => file.startsWith('test_'));

testFiles.forEach(testFile => {
    console.log(`Running ${testFile}`);
    require(path.join(__dirname, testFile));
});
