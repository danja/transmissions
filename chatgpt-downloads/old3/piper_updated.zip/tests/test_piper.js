
import { Piper } from '../'../di/Piper';

// Test for Piper
console.log('Testing Piper...';

try {
    const instance = new Piper();
    console.log('Piper Test Passed';
} catch (error) {
    console.error('Piper Test Failed:', error.message);
}
