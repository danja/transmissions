
const ServiceContainer = require('../ServiceContainer.js');
console.log('Testing ServiceContainer...');

// Example test (to be replaced with actual tests)
const instance = new ServiceContainer();
console.log(instance ? 'Test passed' : 'Test failed');
