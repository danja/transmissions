
const DependencyInjector = require('../DependencyInjector.js');
console.log('Testing DependencyInjector...');

// Example test (to be replaced with actual tests)
const instance = new DependencyInjector();
console.log(instance ? 'Test passed' : 'Test failed');
