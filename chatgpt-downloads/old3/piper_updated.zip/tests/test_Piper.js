
const Piper = require('../Piper.js');
console.log('Testing Piper...');

// Example test (to be replaced with actual tests)
const instance = new Piper();
console.log(instance ? 'Test passed' : 'Test failed');
