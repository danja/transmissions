
export class ServiceContainer {
  constructor(pipeline) {
    this.pipelineConfig = pipeline;
    this.instances = {};
  }

  async getService(serviceName) {
    if (!this.instances[serviceName]) {
      // Dynamically import the service module based on the serviceName
      const module = await import('../services/' + serviceName + '.js');
      const ServiceClass = module[serviceName];
      if (ServiceClass) {
        this.instances[serviceName] = new ServiceClass();
      } else {
        throw new Error('Service ' + serviceName + ' is not defined.');
      }
    }
    return this.instances[serviceName];
  }

  async executePipeline() {
    if (!Array.isArray(this.pipelineConfig) || this.pipelineConfig.length === 0) {
      throw new Error('Pipeline configuration is not valid.');
    }

    let result;
    for (const serviceInfo of this.pipelineConfig) {
      const service = await this.getService(serviceInfo.node);
      result = service.process(result);
    }

    return result;
  }
}
