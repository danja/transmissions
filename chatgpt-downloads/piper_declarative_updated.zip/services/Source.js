import { Injectable } from '../di/Injectable.js';

export class Source extends Injectable {

    read(sourceID) {
        return "Source interface called, oops."
    }
}




